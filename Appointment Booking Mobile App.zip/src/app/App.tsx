import { useState, useEffect } from "react";
import { WelcomeScreen } from "@/app/components/WelcomeScreen";
import { ServiceSelection } from "@/app/components/ServiceSelection";
import { StaffSelection } from "@/app/components/StaffSelection";
import { DateTimeSelection } from "@/app/components/DateTimeSelection";
import { BookingConfirmation } from "@/app/components/BookingConfirmation";
import { BookingHistory } from "@/app/components/BookingHistory";
import {
  Service,
  Staff,
  Booking,
  BookingState,
} from "@/app/types/booking";

type Screen =
  | "welcome"
  | "service"
  | "staff"
  | "datetime"
  | "confirmation"
  | "history";

export default function App() {
  const [currentScreen, setCurrentScreen] =
    useState<Screen>("welcome");
  const [bookingState, setBookingState] =
    useState<BookingState>({});
  const [bookings, setBookings] = useState<Booking[]>([]);

  // Load bookings from localStorage on mount
  useEffect(() => {
    const savedBookings = localStorage.getItem(
      "serenity_bookings",
    );
    if (savedBookings) {
      const parsed = JSON.parse(savedBookings);
      // Convert date strings back to Date objects
      const bookingsWithDates = parsed.map((b: any) => ({
        ...b,
        date: new Date(b.date),
        createdAt: new Date(b.createdAt),
      }));
      setBookings(bookingsWithDates);
    }
  }, []);

  // Save bookings to localStorage whenever they change
  useEffect(() => {
    if (bookings.length > 0) {
      localStorage.setItem(
        "serenity_bookings",
        JSON.stringify(bookings),
      );
    }
  }, [bookings]);

  const handleGetStarted = () => {
    setCurrentScreen("service");
  };

  const handleServiceSelect = (service: Service) => {
    setBookingState({ ...bookingState, service });
    setCurrentScreen("staff");
  };

  const handleStaffSelect = (staff: Staff) => {
    setBookingState({ ...bookingState, staff });
    setCurrentScreen("datetime");
  };

  const handleDateTimeConfirm = (
    date: Date,
    timeSlot: string,
  ) => {
    setBookingState({ ...bookingState, date, timeSlot });

    // Create new booking
    if (bookingState.service && bookingState.staff) {
      const newBooking: Booking = {
        id: `booking_${Date.now()}`,
        service: bookingState.service,
        staff: bookingState.staff,
        date,
        timeSlot,
        status: "upcoming",
        createdAt: new Date(),
      };

      setBookings([...bookings, newBooking]);
    }

    setCurrentScreen("confirmation");
  };

  const handleViewBookings = () => {
    setCurrentScreen("history");
  };

  const handleBookAnother = () => {
    setBookingState({});
    setCurrentScreen("service");
  };

  const handleBackToWelcome = () => {
    setBookingState({});
    setCurrentScreen("welcome");
  };

  return (
    <div className="size-full bg-gray-50">
      {currentScreen === "welcome" && (
        <WelcomeScreen onGetStarted={handleGetStarted} />
      )}

      {currentScreen === "service" && (
        <ServiceSelection
          onBack={handleBackToWelcome}
          onServiceSelect={handleServiceSelect}
        />
      )}

      {currentScreen === "staff" && bookingState.service && (
        <StaffSelection
          selectedService={bookingState.service}
          onBack={() => setCurrentScreen("service")}
          onStaffSelect={handleStaffSelect}
        />
      )}

      {currentScreen === "datetime" &&
        bookingState.service &&
        bookingState.staff && (
          <DateTimeSelection
            selectedService={bookingState.service}
            selectedStaff={bookingState.staff}
            onBack={() => setCurrentScreen("staff")}
            onConfirm={handleDateTimeConfirm}
          />
        )}

      {currentScreen === "confirmation" &&
        bookingState.service &&
        bookingState.staff &&
        bookingState.date &&
        bookingState.timeSlot && (
          <BookingConfirmation
            service={bookingState.service}
            staff={bookingState.staff}
            date={bookingState.date}
            timeSlot={bookingState.timeSlot}
            onViewBookings={handleViewBookings}
            onBookAnother={handleBookAnother}
          />
        )}

      {currentScreen === "history" && (
        <BookingHistory
          bookings={bookings}
          onBack={handleBackToWelcome}
          onBookNew={handleBookAnother}
        />
      )}
    </div>
  );
}