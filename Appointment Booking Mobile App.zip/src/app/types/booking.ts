export interface Service {
  id: string;
  name: string;
  duration: number; // in minutes
  price: number;
  icon: string;
  category: string;
}

export interface Staff {
  id: string;
  name: string;
  role: string;
  rating: number;
  avatar: string;
  specialties: string[];
}

export interface TimeSlot {
  time: string;
  available: boolean;
}

export interface Booking {
  id: string;
  service: Service;
  staff: Staff;
  date: Date;
  timeSlot: string;
  status: 'upcoming' | 'completed' | 'cancelled';
  createdAt: Date;
}

export interface BookingState {
  service?: Service;
  staff?: Staff;
  date?: Date;
  timeSlot?: string;
}
