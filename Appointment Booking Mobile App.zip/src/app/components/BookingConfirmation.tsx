import { CheckCircle2, Calendar, Clock, User, MapPin, Phone, IndianRupee } from 'lucide-react';
import { Service, Staff } from '@/app/types/booking';
import { Button } from '@/app/components/ui/button';
import { format } from 'date-fns';

interface BookingConfirmationProps {
  service: Service;
  staff: Staff;
  date: Date;
  timeSlot: string;
  onViewBookings: () => void;
  onBookAnother: () => void;
}

export function BookingConfirmation({
  service,
  staff,
  date,
  timeSlot,
  onViewBookings,
  onBookAnother
}: BookingConfirmationProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 flex flex-col">
      {/* Success Animation */}
      <div className="flex-1 flex flex-col items-center justify-center p-6">
        <div className="w-24 h-24 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mb-6 shadow-2xl animate-in zoom-in duration-500">
          <CheckCircle2 className="w-14 h-14 text-white" />
        </div>

        <h1 className="text-3xl font-bold text-gray-900 mb-2 text-center">
          Booking Confirmed!
        </h1>
        <p className="text-gray-600 text-center mb-8">
          Your appointment has been successfully scheduled
        </p>

        {/* Booking Details Card */}
        <div className="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-rose-500 to-purple-600 p-6 text-white">
            <h2 className="text-xl font-semibold">{service.name}</h2>
            <p className="text-white/90 text-sm mt-1">Serenity Spa & Salon</p>
          </div>

          {/* Details */}
          <div className="p-6 space-y-4">
            {/* Date & Time */}
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Calendar className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Date & Time</p>
                <p className="font-semibold text-gray-900">
                  {format(date, 'EEEE, MMMM d, yyyy')}
                </p>
                <p className="font-semibold text-gray-900">{timeSlot}</p>
              </div>
            </div>

            {/* Duration */}
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Clock className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Duration</p>
                <p className="font-semibold text-gray-900">{service.duration} minutes</p>
              </div>
            </div>

            {/* Staff */}
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center flex-shrink-0 text-xl">
                {staff.avatar}
              </div>
              <div>
                <p className="text-sm text-gray-600">Specialist</p>
                <p className="font-semibold text-gray-900">{staff.name}</p>
                <p className="text-sm text-gray-600">{staff.role}</p>
              </div>
            </div>

            {/* Price */}
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                <IndianRupee className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Amount</p>
                <p className="font-semibold text-gray-900 text-xl">₹{service.price}</p>
              </div>
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-gray-200 mx-6"></div>

          {/* Location & Contact */}
          <div className="p-6 space-y-3 bg-gray-50">
            <div className="flex items-center gap-2 text-sm">
              <MapPin className="w-4 h-4 text-gray-600" />
              <span className="text-gray-700">MG Road, Bangalore - 560001</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Phone className="w-4 h-4 text-gray-600" />
              <span className="text-gray-700">+91 98765 43210</span>
            </div>
          </div>
        </div>

        {/* Booking ID */}
        <div className="mt-6 text-center">
          <p className="text-xs text-gray-500">Booking ID</p>
          <p className="text-sm font-mono font-semibold text-gray-700">
            SPA{Math.floor(Math.random() * 100000).toString().padStart(5, '0')}
          </p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="p-4 bg-white border-t border-gray-200 space-y-3">
        <Button
          onClick={onViewBookings}
          className="w-full h-12 bg-gradient-to-r from-rose-500 to-purple-600 hover:from-rose-600 hover:to-purple-700 text-white rounded-xl"
        >
          View My Bookings
        </Button>
        <Button
          onClick={onBookAnother}
          variant="outline"
          className="w-full h-12 border-2 border-gray-300 rounded-xl"
        >
          Book Another Service
        </Button>
      </div>
    </div>
  );
}
