import { ArrowLeft, Scissors, Palette, Sparkles, Hand, PaintbrushVertical, Sparkle, Clock, IndianRupee } from 'lucide-react';
import { Service } from '@/app/types/booking';
import { services } from '@/app/data/mockData';
import { Button } from '@/app/components/ui/button';

interface ServiceSelectionProps {
  onBack: () => void;
  onServiceSelect: (service: Service) => void;
}

const iconMap: Record<string, any> = {
  Scissors,
  Palette,
  Sparkles,
  Hand,
  PaintbrushVertical,
  Sparkle
};

export function ServiceSelection({ onBack, onServiceSelect }: ServiceSelectionProps) {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="flex items-center gap-4 p-4">
          <button
            onClick={onBack}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xl font-semibold">Select Service</h1>
            <p className="text-sm text-gray-600">Choose what you'd like today</p>
          </div>
        </div>
      </div>

      {/* Services Grid */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="space-y-3 max-w-2xl mx-auto">
          {services.map((service) => {
            const IconComponent = iconMap[service.icon];
            return (
              <button
                key={service.id}
                onClick={() => onServiceSelect(service)}
                className="w-full bg-white rounded-2xl p-4 border-2 border-gray-200 hover:border-rose-400 active:scale-[0.98] transition-all shadow-sm"
              >
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-gradient-to-br from-rose-100 to-purple-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    {IconComponent && <IconComponent className="w-7 h-7 text-rose-600" />}
                  </div>
                  
                  <div className="flex-1 text-left">
                    <h3 className="font-semibold text-gray-900">{service.name}</h3>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="flex items-center text-sm text-gray-600">
                        <Clock className="w-4 h-4 mr-1" />
                        {service.duration} min
                      </span>
                      <span className="flex items-center text-sm font-semibold text-rose-600">
                        <IndianRupee className="w-4 h-4" />
                        {service.price}
                      </span>
                    </div>
                  </div>

                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                      <svg className="w-5 h-5 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Popular Badge */}
      <div className="p-4 bg-white border-t border-gray-200">
        <div className="max-w-2xl mx-auto text-center">
          <p className="text-sm text-gray-600">
            💎 Most popular: <span className="font-semibold text-gray-900">Hair Cut & Styling</span>
          </p>
        </div>
      </div>
    </div>
  );
}
