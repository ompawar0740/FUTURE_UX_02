import { useState, useMemo } from 'react';
import { ArrowLeft, Calendar as CalendarIcon, Clock } from 'lucide-react';
import { Service, Staff } from '@/app/types/booking';
import { generateTimeSlots } from '@/app/data/mockData';
import { Button } from '@/app/components/ui/button';
import { format, addDays, isSameDay } from 'date-fns';

interface DateTimeSelectionProps {
  selectedService: Service;
  selectedStaff: Staff;
  onBack: () => void;
  onConfirm: (date: Date, timeSlot: string) => void;
}

export function DateTimeSelection({
  selectedService,
  selectedStaff,
  onBack,
  onConfirm
}: DateTimeSelectionProps) {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedTime, setSelectedTime] = useState<string | null>(null);

  // Generate next 7 days
  const dates = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => addDays(new Date(), i));
  }, []);

  // Get time slots for selected date
  const timeSlots = useMemo(() => {
    return generateTimeSlots(selectedDate);
  }, [selectedDate]);

  const handleConfirm = () => {
    if (selectedTime) {
      onConfirm(selectedDate, selectedTime);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="flex items-center gap-4 p-4">
          <button
            onClick={onBack}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-semibold">Select Date & Time</h1>
            <p className="text-sm text-gray-600">with {selectedStaff.name}</p>
          </div>
        </div>

        {/* Service Summary */}
        <div className="px-4 pb-4">
          <div className="bg-gradient-to-r from-rose-50 to-purple-50 rounded-xl p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-gray-900">{selectedService.name}</p>
                <p className="text-sm text-gray-600 mt-0.5">
                  {selectedService.duration} min • ₹{selectedService.price}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Date Selection */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center gap-2 mb-3">
          <CalendarIcon className="w-5 h-5 text-gray-600" />
          <h2 className="font-semibold text-gray-900">Choose Date</h2>
        </div>
        
        <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4">
          {dates.map((date, idx) => {
            const isSelected = isSameDay(date, selectedDate);
            const isToday = idx === 0;
            
            return (
              <button
                key={idx}
                onClick={() => setSelectedDate(date)}
                className={`flex-shrink-0 flex flex-col items-center justify-center w-16 h-20 rounded-xl border-2 transition-all ${
                  isSelected
                    ? 'bg-gradient-to-br from-rose-500 to-purple-600 border-transparent text-white shadow-lg'
                    : 'bg-white border-gray-200 hover:border-gray-300 text-gray-900'
                }`}
              >
                <span className="text-xs font-medium opacity-80">
                  {isToday ? 'Today' : format(date, 'EEE')}
                </span>
                <span className="text-xl font-bold mt-1">{format(date, 'd')}</span>
                <span className="text-xs opacity-80">{format(date, 'MMM')}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Time Slot Selection */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="flex items-center gap-2 mb-3">
          <Clock className="w-5 h-5 text-gray-600" />
          <h2 className="font-semibold text-gray-900">Available Time Slots</h2>
        </div>

        <div className="grid grid-cols-3 gap-2 max-w-2xl mx-auto">
          {timeSlots.map((slot, idx) => {
            const isSelected = selectedTime === slot.time;
            
            return (
              <button
                key={idx}
                onClick={() => slot.available && setSelectedTime(slot.time)}
                disabled={!slot.available}
                className={`h-12 rounded-xl border-2 font-semibold transition-all ${
                  !slot.available
                    ? 'bg-gray-100 border-gray-200 text-gray-400 cursor-not-allowed'
                    : isSelected
                    ? 'bg-gradient-to-br from-rose-500 to-purple-600 border-transparent text-white shadow-lg scale-105'
                    : 'bg-white border-gray-200 hover:border-purple-300 text-gray-900 active:scale-95'
                }`}
              >
                {slot.time}
              </button>
            );
          })}
        </div>

        {timeSlots.filter(s => s.available).length === 0 && (
          <div className="text-center py-8">
            <p className="text-gray-500">No available slots for this date</p>
          </div>
        )}
      </div>

      {/* Confirm Button */}
      <div className="p-4 bg-white border-t border-gray-200">
        <Button
          onClick={handleConfirm}
          disabled={!selectedTime}
          className="w-full h-14 text-lg bg-gradient-to-r from-rose-500 to-purple-600 hover:from-rose-600 hover:to-purple-700 text-white rounded-xl shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {selectedTime
            ? `Confirm for ${format(selectedDate, 'MMM d')} at ${selectedTime}`
            : 'Select a time slot'}
        </Button>
      </div>
    </div>
  );
}
