import { Sparkles, Calendar, CheckCircle2, Scissors } from 'lucide-react';
import { Button } from '@/app/components/ui/button';

interface WelcomeScreenProps {
  onGetStarted: () => void;
}

export function WelcomeScreen({ onGetStarted }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-purple-50 flex flex-col">
      {/* Header with logo */}
      <div className="p-6 text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-rose-500 to-purple-600 rounded-2xl mb-4 shadow-lg">
          <Sparkles className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-rose-600 to-purple-600 bg-clip-text text-transparent">
          Serenity Spa & Salon
        </h1>
        <p className="text-gray-600 mt-2">Your Beauty, Our Passion</p>
      </div>

      {/* Hero Section */}
      <div className="flex-1 flex flex-col justify-center px-6 pb-12">
        <div className="space-y-8">
          <div className="text-center space-y-4">
            <h2 className="text-2xl font-semibold text-gray-800">
              Book Your Perfect Appointment
            </h2>
            <p className="text-gray-600 max-w-sm mx-auto">
              Experience premium salon services at your convenience. Book instantly, skip the wait.
            </p>
          </div>

          {/* Features */}
          <div className="space-y-4 max-w-md mx-auto">
            <div className="flex items-start gap-4 bg-white/60 backdrop-blur-sm p-4 rounded-xl">
              <div className="w-10 h-10 bg-rose-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Scissors className="w-5 h-5 text-rose-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">Choose Your Service</h3>
                <p className="text-sm text-gray-600">Select from hair, skin, nails, and more</p>
              </div>
            </div>

            <div className="flex items-start gap-4 bg-white/60 backdrop-blur-sm p-4 rounded-xl">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Calendar className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">Pick Date & Time</h3>
                <p className="text-sm text-gray-600">Book a slot that works for you</p>
              </div>
            </div>

            <div className="flex items-start gap-4 bg-white/60 backdrop-blur-sm p-4 rounded-xl">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">Instant Confirmation</h3>
                <p className="text-sm text-gray-600">Get confirmed in seconds</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Button */}
      <div className="p-6 bg-white/80 backdrop-blur-sm border-t border-gray-200">
        <Button
          onClick={onGetStarted}
          className="w-full h-14 text-lg bg-gradient-to-r from-rose-500 to-purple-600 hover:from-rose-600 hover:to-purple-700 text-white rounded-xl shadow-lg"
        >
          Get Started
        </Button>
        <p className="text-center text-xs text-gray-500 mt-3">
          No registration required • Walk-ins welcome
        </p>
      </div>
    </div>
  );
}
