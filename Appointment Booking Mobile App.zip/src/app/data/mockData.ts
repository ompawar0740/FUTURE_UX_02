import { Service, Staff } from '@/app/types/booking';

export const services: Service[] = [
  {
    id: 's1',
    name: 'Hair Cut & Styling',
    duration: 45,
    price: 800,
    icon: 'Scissors',
    category: 'Hair'
  },
  {
    id: 's2',
    name: 'Hair Coloring',
    duration: 120,
    price: 2500,
    icon: 'Palette',
    category: 'Hair'
  },
  {
    id: 's3',
    name: 'Facial Treatment',
    duration: 60,
    price: 1500,
    icon: 'Sparkles',
    category: 'Skin'
  },
  {
    id: 's4',
    name: 'Deep Tissue Massage',
    duration: 90,
    price: 2000,
    icon: 'Hand',
    category: 'Massage'
  },
  {
    id: 's5',
    name: 'Manicure & Pedicure',
    duration: 60,
    price: 1200,
    icon: 'PaintbrushVertical',
    category: 'Nails'
  },
  {
    id: 's6',
    name: 'Bridal Makeup',
    duration: 180,
    price: 5000,
    icon: 'Sparkle',
    category: 'Makeup'
  }
];

export const staff: Staff[] = [
  {
    id: 'st1',
    name: 'Priya Sharma',
    role: 'Senior Hair Stylist',
    rating: 4.9,
    avatar: '👩🏻',
    specialties: ['Hair Cut', 'Hair Coloring', 'Styling']
  },
  {
    id: 'st2',
    name: 'Ananya Reddy',
    role: 'Skin Specialist',
    rating: 4.8,
    avatar: '👩🏽',
    specialties: ['Facial', 'Skin Treatment']
  },
  {
    id: 'st3',
    name: 'Meera Iyer',
    role: 'Massage Therapist',
    rating: 4.9,
    avatar: '👩🏾',
    specialties: ['Massage', 'Aromatherapy']
  },
  {
    id: 'st4',
    name: 'Kavya Patel',
    role: 'Makeup Artist',
    rating: 5.0,
    avatar: '👩🏻‍🦰',
    specialties: ['Bridal Makeup', 'Party Makeup']
  },
  {
    id: 'st5',
    name: 'Sneha Kumar',
    role: 'Nail Technician',
    rating: 4.7,
    avatar: '👩🏽‍🦱',
    specialties: ['Manicure', 'Pedicure', 'Nail Art']
  }
];

export const generateTimeSlots = (date: Date): { time: string; available: boolean }[] => {
  const slots = [];
  const hours = [9, 10, 11, 12, 14, 15, 16, 17, 18];
  
  for (const hour of hours) {
    const slot = `${hour.toString().padStart(2, '0')}:00`;
    // Randomly mark some slots as unavailable for demo purposes
    const available = Math.random() > 0.3;
    slots.push({ time: slot, available });
  }
  
  return slots;
};
